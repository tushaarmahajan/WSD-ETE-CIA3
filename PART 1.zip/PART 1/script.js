const API_URL = 'https://newsapi.org/v2/top-headlines';

let currentPage = 1;
const articlesPerPage = 5;

// Fetch news articles
async function fetchNews(category = '', sortBy = 'publishedAt') {
    try {
        const response = await fetch(`${API_URL}?country=us&category=${category}&sortBy=${sortBy}&pageSize=${articlesPerPage}&page=${currentPage}&apiKey=${API_KEY}`);
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        return data.articles;
    } catch (error) {
        console.error('Error fetching news:', error);
        return [];
    }
}

// Display news articles
function displayNews(articles) {
    const newsList = document.getElementById('news-list');
    newsList.innerHTML = '';

    if (articles.length === 0) {
        newsList.innerHTML = '<p>No news articles found.</p>';
        return;
    }

    articles.forEach(article => {
        const articleDiv = document.createElement('div');
        articleDiv.className = 'article';
        articleDiv.innerHTML = `
            <h3>${article.title}</h3>
            <p>${article.description}</p>
            <a href="${article.url}" target="_blank">Read more</a>
        `;
        newsList.appendChild(articleDiv);
    });
}

// Handle page navigation
function handlePagination() {
    document.getElementById('prev-page').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            loadNews();
        }
    });

    document.getElementById('next-page').addEventListener('click', () => {
        currentPage++;
        loadNews();
    });
}

// Load news articles
async function loadNews() {
    const category = document.getElementById('category').value;
    const sortBy = document.getElementById('sort').value;
    const articles = await fetchNews(category, sortBy);
    displayNews(articles);
    document.getElementById('page-number').innerText = `Page ${currentPage}`;
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadNews();
    handlePagination();

    document.getElementById('category').addEventListener('change', loadNews);
    document.getElementById('sort').addEventListener('change', loadNews);
});
