document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorElement = document.getElementById('signup-error');

    if (username.length < 3) {
        errorElement.textContent = 'Username must be at least 3 characters long.';
        return;
    }

    if (password.length < 6) {
        errorElement.textContent = 'Password must be at least 6 characters long.';
        return;
    }

    // Simulate successful registration
    document.getElementById('signup-section').classList.add('hidden');
    document.getElementById('news-section').classList.remove('hidden');
    errorElement.textContent = '';
});
